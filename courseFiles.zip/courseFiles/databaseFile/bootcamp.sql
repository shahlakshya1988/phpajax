-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2019 at 05:01 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bootcamp`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `id` int(11) NOT NULL,
  `bookName` varchar(100) NOT NULL,
  `authorName` varchar(100) NOT NULL,
  `price` varchar(100) NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`id`, `bookName`, `authorName`, `price`, `userId`) VALUES
(8, 'GraphQL For Beginners', 'John', '30', 15),
(9, 'VueJS Course', 'Shakil', '40', 11),
(10, 'PHP For Beginners', 'Shakil Khan', '40', 18),
(11, 'React For Beginners', 'Rahul', '30', 18),
(12, 'React For Beginners', 'Shakil Khan', '40', 19),
(13, 'NodeJS For beginners', 'Deo', '40', 19),
(14, 'React for beginners', 'shakil khan', '30', 20),
(15, 'NodeJS for beginners', 'Asad', '20', 20),
(16, 'PHP For Beginners', 'Shakil Khan', '30', 21),
(18, 'React for beginners', 'Shakil khan', '30', 22),
(37, 'Biology', 'Shakir', '30', 23),
(38, 'Physics', 'Azhar', '20', 23),
(39, 'my book', 'Smith', '40', 23),
(40, 'xyz book', 'Sharjeel', '50', 23),
(41, 'react book', 'arish', '40', 23),
(42, 'angular', 'sahe', '40', 23),
(43, 'vue book', 'rahul', '40', 23),
(44, 'java book', 'shakil', '30', 23),
(45, 'webpack 4 book', 'shakil khan', '30', 23),
(46, 'javascript book', 'arshad', '20', 23),
(47, 'C# Book', 'joy', '30', 23),
(48, 'flutter book', 'abdullah', '20', 23),
(49, 'dart programming', 'shakil', '20', 23),
(50, 'Javascript book', 'Shakil', '20', 15),
(51, 'React Book', 'Brad', '30', 15),
(52, 'VueJS Book', 'Shakil Khan', '20', 15),
(53, 'C++ Book', 'Rahul', '40', 15),
(54, 'C# Book', 'Javed', '30', 15),
(55, 'Go programming', 'Shakil khan', '30', 15),
(56, 'Flutter Framework', 'Rahul', '20', 15),
(57, 'Dart progrmaming', 'Sadiq', '30', 15),
(58, 'computer applications', 'Sajjad', '40', 15),
(59, 'Hardware and Software', 'Kamran', '20', 15),
(60, 'Software Engineering', 'Shakil khan', '40', 15),
(61, 'Computer Scince', 'Ahmed', '50', 15),
(62, 'Python Language', 'Jon Deo', '40', 15),
(63, 'Clean Code', 'Smith', '30', 15),
(64, 'English Language', 'Brad', '50', 15);

-- --------------------------------------------------------

--
-- Table structure for table `gallery`
--

CREATE TABLE `gallery` (
  `imageId` int(11) NOT NULL,
  `imageName` varchar(255) NOT NULL,
  `userId` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `fullName` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `fullName`, `email`, `password`) VALUES
(1, 'Shakil Khan', 'shakilkhan@gmail.com', '12345'),
(3, 'Shakil khan', 'shakilkhan@yahoo.com', '123456'),
(4, 'John', 'john@gmail.com', '12345'),
(5, 'john', 'john@yahoo.com', '$2y$10$BlO4riVmTZHJtGj2iYwVy.hlwfwpRs4qNgGSQVuFZziwceXk6r4xe'),
(9, 'paul', 'paul@gmail.com', '$2y$10$7IuPdZAwVpO2IghCltHGQ.scUZ/7vSvvs5rWb4B8x7tBkPe8ZFY5S'),
(10, 'rahul', 'rahul@gmail.com', '$2y$10$YjKU23X1rY/2HYvRKCYXk.2k3WHaygHuRRpebdizGG9JfAC/KUVOq'),
(11, 'smith', 'smith@gmail.com', '$2y$10$VNinl0iUHjAoYyvlIVJHr.hf.GLZJRdRYpghBVBJikQVUoNR/hx3i'),
(13, 'brad', 'brad@gmail.com', '$2y$10$wCKuLjdMdlXQ9jexP0NfUeSpGEPinciyFeDSu87paWA1xxRnWjKg6'),
(14, 'Ashfaq', 'ashfaq@gmail.com', '$2y$10$zGdQeJuQ6ft1WGF7qoF2X.YKAvNEG2fJQ3a.Nu.tNukmSHuZZpfa2'),
(15, 'abbas', 'abbas@gmail.com', '$2y$10$fMOMvpckROb1nDm/FIs8vutJJR0zPXdu0ShIZhu8jQKwBo5OGaRcC'),
(16, 'wali', 'wali@gmail.com', '$2y$10$c2CprWCNzBbO7CCUuL1UVeUZ24Fb1tJIHa16FtmxU/iN29yd21wIW'),
(17, 'kamran', 'kamran@gmail.com', '$2y$10$9IXxP6hhirww54PwhX.i8O8sCWci7k7x5.yvZgal8rMNVVfRUKiTK'),
(18, 'sara', 'sara@gmail.com', '$2y$10$fVCGnmBM8WRVYbheIw9HbOMDXwT8Vth4ilJneYHvSBb0k.ePw.Ilm'),
(19, 'salman', 'salman@gmail.com', '$2y$10$ijWyFmoooRD54QJg1G.Bh.bOPqYtNQBJD5fycqySs11RO9UjoQCmS'),
(20, 'umer', 'umer@gmail.com', '$2y$10$6bCO1jl2YZjmZCqk.TIMUe4q0OPqf3pJ7o09cHmQbTgIDQ7dyUVYy'),
(21, 'usman', 'usman@gmail.com', '$2y$10$HpjA9dNHAPS33HkWtqVFde.4fR9OG0g9gECsTXQ30NbRP7UVXLm3u'),
(22, 'sammad', 'sammad@gmail.com', '$2y$10$f7OCSbFJwWWRN29vGTfoOOXbZyPSWAnUCXLB2zgLjRTX.a5aSrod.'),
(23, 'zahid', 'zahid@gmail.com', '$2y$10$ELPGvCo7EidHLasgS0XDVuAL2Yuf3WC4ASUMI49xP7OuvH3u4wIaa');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`imageId`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=65;

--
-- AUTO_INCREMENT for table `gallery`
--
ALTER TABLE `gallery`
  MODIFY `imageId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
