<nav id="nav">
  	<ul class="left">
  		<li><a href="dashboard.php">Home</a></li>
  		<li><a href="gallery.php">Gallery</a></li>
  		<li class="right"><a href="logout.php" class="btn btn-default">Logout</a></li>
  	</ul>
  </nav>