<div class="group">
						<h2 class="accountHeading"><span class="lg">Login</span> to your account</h2>
					</div>
					<!-- Close group -->
		   <!-- <h3>Let's create your account</h3> -->
		   <form id="loginForm">
				<div class="group">
					<input type="email" id="email" name="email" class="control" placeholder="Email...">
					<div class="error emailError">

					</div>
				</div>
				<!-- Close group -->
				<div class="group">
					<input type="password" id="password" name="password" class="control" placeholder="Enter Password...">
					<div class="error passwordError"></div>
				</div>
				<!-- Close group -->
				
				<div class="group mt-20">
					<input type="submit" id="signup" class="btn btn-sweet" value="Login &#8250;">
				</div>
				<!-- Close group -->
				
			</form>
			<!-- Close form -->
			<div class="space">
				<span class="linksDesign">
						Create new account <a href="index.php">Register</a>
				</span>
				<!-- Close linksDesign -->
			</div>
			<!-- Close space -->