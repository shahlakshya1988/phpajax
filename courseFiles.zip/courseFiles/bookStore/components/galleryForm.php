<form id="galleryForm" enctype="multipart/form-data">
			<label for="imageInput" id="custom-label"></label>
			<input type="file" name="image" id="imageInput" class="img-input" onchange = "imageName();">
			<input type="hidden" class="addBookBtn">
		</form>