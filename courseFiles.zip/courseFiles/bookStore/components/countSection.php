<div class="countSection">
		<div class="counting">
         <div class="count totalBooks">Total Books<h2>250.00</h2></div>
		</div>
		<!-- Close counting -->

		<div class="counting mt-20">
				<div class="count totalAmount">Total Amount <h2> $345345.00</h2></div>
		</div>
			   <!-- Close counting -->
	</div>
	<!-- Close countSection -->