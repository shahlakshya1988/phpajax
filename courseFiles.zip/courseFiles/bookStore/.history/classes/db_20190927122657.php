<?php

class db  {

    public $connection;
    public function __construct(){
    
    try {
    $this->connection = new PDO("mysql:host=" . HOST . ";dbname=" . DBNAME, USER , PASSWORD);
    $this->connection->setAttribute(PDO::ATTR_EMULATE_PREPARES, FALSE);


    } catch(PDOException $e){

        echo "Connection error: " . $e->getMessage();

    }

    }

}



?>