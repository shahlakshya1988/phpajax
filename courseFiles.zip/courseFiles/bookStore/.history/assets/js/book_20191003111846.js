const bookForm          = document.getElementById("bookForm");
const bookName          = document.getElementById("bookName");
const bookAuthor        = document.getElementById("bookAuthor");
const bookPrice         = document.getElementById("bookPrice");
const nameError         = document.querySelector(".nameError");
const autherError       = document.querySelector(".authorError");
const priceError        = document.querySelector(".priceError");
const bookStatus        = document.getElementById("bookStatus");
const message           = document.querySelector(".message");
let heading             = document.querySelector(".heading");
let bookButton          = document.getElementById("bookButton");
const modelContainer    = document.querySelector(".model-container");
const bookId            = document.getElementById("bookId");
const totalBooks        = document.querySelector(".totalBooks");
const totalAmount       = document.querySelector(".totalAmount");
let nameStatus = autherStatus = priceStatus = true;

// Event listener for book 
      bookForm.addEventListener("submit", (e) => {

        e.preventDefault();
        
        // Book name validations
        if(Empty(bookName, "Book Name", nameError)){
            nameStatus = false;
 
        } else {
            nameStatus = true;
        }


        // Author validations 
        if(Empty(bookAuthor, "Author Name", autherError)){
            autherStatus = false;
            if(NotInt(bookAuthor, "Author Name", autherError)){
                autherStatus = false;
            } else {
                autherStatus = true;
            }
        } else {
            autherStatus = true;
        }


        // Book price validations
        if(Empty(bookPrice, "Price", priceError)){
            priceStatus = false;
            if(Positive(bookPrice, 'Price', priceError)){
                priceStatus = false;
            } else {
                priceStatus = true;
            }
            
        } else {
            priceStatus = true;
        }

        
        if(nameStatus === false && autherStatus === false && priceStatus === false ){
            console.log('submitted');

            // Send ajax request for add book
            if(bookStatus.value === "addBook"){
                $.ajax({

                    type : 'POST',
                    url  : 'ajax/addBook.php',
                    data : $(bookForm).serialize(),
                    success : (response) => {
                        
                        const convertedRes = JSON.parse(response);
                        if(convertedRes.status === "success"){
                            modelContainer.style.display = "none";
                            bookForm.reset();
                            message.innerHTML = `<div class="alert success">
                            <div class="alert-icon"><div class="alertIcon">&check;</div></div>
                            <p> <strong>Success!</strong> ${convertedRes.msg} </p>
                        </div>`;
                        hidMessage();
                        fetchBooks();
                        booksInfo();
                        }

                    }

                })
            } else if(bookStatus.value === "updateBook"){

                $.ajax({
                    type : 'POST',
                    url  : 'ajax/updateBook.php',
                    data : $(bookForm).serialize(),
                    success : (response) => {
                        const convertedRes = JSON.parse(response);
                        if(convertedRes.status === "success"){
                            modelContainer.style.display = "none";
                            bookForm.reset();
                            message.innerHTML = `<div class="alert success">
                            <div class="alert-icon"><div class="alertIcon">&check;</div></div>
                            <p> <strong>Success!</strong> ${convertedRes.msg} </p>
                        </div>`;
                        hidMessage();
                        fetchBooks();
                        booksInfo();
                            
                        }
                    }
                })

            }
        }


      })


      let record_per_page = 3;
      let page = 1;
     
     
      

function fetchBooks(){
    let start_from = ( page - 1 ) *  record_per_page;
    console.log(start_from, page,"My page");
    let table = document.getElementById("table");
    

    $.ajax({

        type : 'POST',
        url  : 'ajax/fetchBooks.php',
        data : {startFrom : start_from, recordPerPage: record_per_page},
        success : (response) => {
            const res = JSON.parse(response);
            if(res.status === "success"){
             
               let result = "";
                res.data.forEach((book) => {

                result += `<tr>
				<td>${book.bookName}</td>
				<td>${book.authorName}</td>
				<td><div class="dollor">$ ${book.price}.00</div></td>
			    <td><a href="" class="btn btn-warning btn-small updateBookBtn" onclick="updateBook(${book.id}, '${book.bookName}', '${book.authorName}', ${book.price});">Edit <span>&#9998;</span></a></td>
			    <td><a href="javascript:void(0);" class="btn btn-danger btn-small" onclick="deleteBook(${book.id});">Delete <span>&#10006;</span></a></td>
			</tr>`;

                })
                table.innerHTML = `<table class="table">
                <thead>
                    <tr>
                        <th>Book Name</th>
                        <th>Author Name</th>
                        <th>Book Price</th>
                        <th>Edit</th>
                        <th>Delete</th>
                    </tr>
                </thead>
                <tbody>${result}</tbody></table>`;

            } else if(res.status === "noRecords"){
                 table.innerHTML = `<div style="font-size:1.4rem;border: 1px solid silver;padding: 1rem;border-radius: 3px;color:silver">No Records</div>`;
            }

            const updateBookBtn = document.querySelectorAll(".updateBookBtn");
                  updateBookBtn.forEach((btn) => {
                   
                    btn.addEventListener("click", (e) => {

                        e.preventDefault();
                        modelBox();

                    })

                  })
        }

    })


}

fetchBooks();

function updateBook(id, bookN, bookA, bookP){

 bookName.value = bookN;
 bookAuthor.value = bookA;
 bookPrice.value = bookP;
 heading.innerHTML = "Update Book";
 bookButton.value = "update book \u276F";
 bookName.classList.remove("borderRed");
 bookAuthor.classList.remove("borderRed");
 bookPrice.classList.remove("borderRed");
 nameError.innerHTML = "";
 autherError.innerHTML = "";
 priceError.innerHTML = "";
 bookStatus.value = "updateBook";
 bookId.value     = id;


}


function addBookForm(){

    bookName.value = "";
    bookAuthor.value = "";
    bookPrice.value = "";
    heading.innerHTML = "Add Book";
    bookButton.value = "add book \u276F";  
    bookStatus.value = "addBook";

}

function deleteBook(id){

    const confirmBox = confirm("Are you really want to delete this book ?");
    if(confirmBox){
        $.ajax({

            type : 'POST',
            url  : 'ajax/deleteBook.php',
            data : {id},
            success : (response) => {
                const convertedRes = JSON.parse(response);
                if(convertedRes.status === "success"){
                    message.innerHTML = `<div class="alert success">
                            <div class="alert-icon"><div class="alertIcon">&check;</div></div>
                            <p> <strong>Success!</strong> ${convertedRes.msg} </p>
                        </div>`;
                        hidMessage();
                        fetchBooks();
                        booksInfo();
                }
            }

        })
    }

}


function booksInfo(){


    $.ajax({

        type : 'GET',
        url  : 'ajax/booksInfo.php',
        success : (response) => {
            
            const res = JSON.parse(response);
            if(res.status === "success"){
                totalBooks.innerHTML = `Total Books<h2>${res.totalBooks}.00</h2>`;
                totalAmount.innerHTML = `Total Amount <h2> $ ${res.totalAmount}.00</h2>`;

            } else if(res.status === "noBooks"){
                totalBooks.innerHTML = `Total Books<h2>0.00</h2>`;
                totalAmount.innerHTML = `Total Amount <h2> $ 0.00</h2>`;
            }

        }

    })

}

booksInfo();


function createPagination(){

    const paginate = document.querySelector(".paginate");

    $.ajax({
        type : 'GET',
        url : 'ajax/countRows.php',
        success : (response) => {

            let res = JSON.parse(response);
            let total_pages = Math.ceil(res.rows/record_per_page);
            let start_loop = page;
            console.log(page);
            let difference = total_pages - page;
            if(difference <= 3)
            {
            start_loop = total_pages - 3;
            }
            let end_loop = start_loop + 3;
            let leftLinks = '';
            let links     = '';
            let rightLinks = '';
            if(page > 1)
            {
            leftLinks =  `<li><a href='javascript:void(0)' onclick="first()">First</a></li><li><a href='javascript:void(0)' onclick="prev()"><<</a>`;
            }
             console.log(start_loop, end_loop, "Start Loop");
            for(let i= start_loop; i<= end_loop; i++)
            {  
                console.log(i, "loop");
            if(i > 0){
            const active = i == page ? 'active' : '';  
            links +=  `<li><a href="javascript:void(0)" class="${active}" onclick="clickLink(${i})">${i}</a></li>`;
            }
            }
            console.log(page, total_pages, "total pages");
            if(page < total_pages)
            {
            rightLinks += `<li><a href='javascript:void(0);' onclick="next()">>></a></li><li><a href='javascript:void(0);'>Last</a><li></li>`;
            } else if(page === total_pages) {
                rightLinks = '';
            }
            if(res.rows > 3){
            paginate.innerHTML = `<ul class="pagination">
            ${leftLinks}  
            ${links} 
            ${rightLinks}         
            </ul>`;
            } 

        }

        
        
    })



}
createPagination();

function next(){

    page = page + 1;
    fetchBooks();
    createPagination();

}

function prev(){

    page = page - 1;
    fetchBooks();
    createPagination();

}

function clickLink(link){

   page = link;
   fetchBooks();
   createPagination();

}