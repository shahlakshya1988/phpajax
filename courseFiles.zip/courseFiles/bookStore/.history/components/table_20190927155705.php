<div class="table-section">
	<div class="message"></div>
	<div id="table"></div>
	<div class="paginate"></div>
	<!-- <table class="table">
		<thead>
			<tr>
				<th>Book Name</th>
				<th>Author Name</th>
				<th>Book Price</th>
				<th>Edit</th>
				<th>Delete</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>PHP For Beginners </td>
				<td>Alex Jorh</td>
				<td><div class="dollor">$50.00</div></td>
			    <td><a href="" class="btn btn-warning btn-small showModel">Edit <span>&#9998;</span></a></td>
			    <td><a href="" class="btn btn-danger btn-small">Delete <span>&#10006;</span></a></td>
			</tr>
			<tr>
				<td>Modern JavaScript</td>
				<td>Brad</td>
				<td><div class="dollor">$100.00</div></td>
			    <td><a href="" class="btn btn-warning btn-small showModel" >Edit <span>&#9998;</span></a></td>
			    <td><a href="" class="btn btn-danger btn-small">Delete <span>&#10006;</span></a></td>
			</tr>
			<tr>
				<td>ReactJS For Beginners</td>
				<td>Colt</td>
				<td><div class="dollor">$190.00</div></td>
			    <td><a href="" class="btn btn-warning btn-small showModel">Edit <span>&#9998;</span></a></td>
			    <td><a href="" class="btn btn-danger btn-small">Delete <span>&#10006;</span></a></td>
			</tr>
		</tbody>
	</table> -->
	<!-- Close table -->
</div>
<!-- Close table-section -->