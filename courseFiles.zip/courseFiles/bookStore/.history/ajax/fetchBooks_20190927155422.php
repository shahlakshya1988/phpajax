<?php
include "../init.php";
$queries = new queries;
$userId = $_SESSION['userId'];
if(isset($_POST['startFrom']) && isset($_POST['recordPerPage'])){

    $startFrom = $_POST['startFrom'];
    $recordPerPage = $_POST['recordPerPage'];

if($queries->Crud("SELECT * FROM books WHERE userId = ? ORDER BY id DESC LIMIT ?,? ", [$userId, $startFrom, $recordPerPage])){
   if($queries->Count() > 0 ){
    $rows = $queries->getAll();
    echo json_encode(["status" => "success", "data" => $rows]);
   } else {
       echo json_encode(["status" => "noRecords"]);
   }
}
}
?>