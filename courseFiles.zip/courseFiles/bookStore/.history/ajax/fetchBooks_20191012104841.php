<?php
include "../init.php";
$queries = new queries;
$userId = $_SESSION['userId'];
$form = new form;
if(isset($_POST['offset']) && isset($_POST['records_per_page'])){

    $offset = $form->input('offset');
    $recordPerPage = $form->input('records_per_page');
    if ($queries->Crud("SELECT * FROM books WHERE userId = ? ORDER BY id DESC LIMIT ?,? ", [$userId, $offset, $recordPerPage])) {
        if ($queries->Count() > 0) {
            $rows = $queries->getAll();
            echo json_encode(["status" => "success", "data" => $rows]);
        } else {
            echo json_encode(["status" => "noRecords"]);
        }
    }

}

