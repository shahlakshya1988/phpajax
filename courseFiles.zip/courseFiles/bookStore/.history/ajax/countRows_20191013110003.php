<?php
include "../init.php";
$queries = new queries;
$userId = $_SESSION['userId'];
if($queries->Crud("SELECT * FROM books WHERE userId = ? ")){

}


?>