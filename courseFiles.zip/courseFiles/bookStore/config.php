<?php

// Database parameters
define("HOST", "localhost");
define("DBNAME", "bootcamp");
define("USER", "root");
define("PASSWORD", "");



?>